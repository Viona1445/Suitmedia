package com.example.suitmediavionaasyaarinda.ui

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.suitmediavionaasyaarinda.R
import com.example.suitmediavionaasyaarinda.adapter.UserAdapter
import com.example.suitmediavionaasyaarinda.response.UserResponse
import com.example.suitmediavionaasyaarinda.response.data
import com.example.suitmediavionaasyaarinda.retrofit.ApiClient
import retrofit2.Response
import retrofit2.Call
import retrofit2.Callback

class AccountRowActivity : AppCompatActivity(), UserAdapter.OnItemClickListener {

    private lateinit var usersAdapter: UserAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyStateTextView: TextView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private var currentPage = 1
    private val perPage = 10

    companion object {
        const val SELECTED_USER_NAME = "SELECTED_USER_NAME"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_row)

        val customActionBar = layoutInflater.inflate(R.layout.action_third_bar_layout, null)
        val params = ActionBar.LayoutParams(
            ActionBar.LayoutParams.WRAP_CONTENT,
            ActionBar.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        )
        supportActionBar?.apply {
            setCustomView(customActionBar, params)
            setDisplayShowCustomEnabled(true)
            setDisplayShowTitleEnabled(false)
            setDisplayHomeAsUpEnabled(true)
        }

        recyclerView = findViewById(R.id.rv_account)
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)
        emptyStateTextView = findViewById(R.id.emptyStateTextView)

        usersAdapter = UserAdapter(this, emptyList(), this)
        recyclerView.adapter = usersAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        swipeRefreshLayout.setOnRefreshListener {
            currentPage = 1
            fetchData()
        }

        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                val layoutManager = recyclerView.layoutManager as LinearLayoutManager
                val visibleItemCount = layoutManager.childCount
                val totalItemCount = layoutManager.itemCount
                val firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition()

                if (!swipeRefreshLayout.isRefreshing && currentPage < totalItemCount / perPage) {
                    if (visibleItemCount + firstVisibleItemPosition >= totalItemCount) {
                        currentPage++
                        fetchData()
                    }
                }
            }
        })

        fetchData()
    }

    override fun onItemClick(data: data) {
        val resultIntent = Intent()
        resultIntent.putExtra(SELECTED_USER_NAME, "${data.first_name} ${data.last_name}")
        setResult(RESULT_OK, resultIntent)
        finish()
    }

    private fun fetchData() {
        swipeRefreshLayout.isRefreshing = true

        val call = ApiClient.api.getUsers(currentPage, perPage)

        call.enqueue(object : Callback<UserResponse> {
            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                if (response.isSuccessful) {
                    val users = response.body()?.data ?: emptyList()
                    if (currentPage == 1) {
                        usersAdapter.setData(users)
                    } else {
                        val currentData = usersAdapter.getData().toMutableList()
                        currentData.addAll(users)
                        usersAdapter.setData(currentData)
                    }
                    showEmptyStateIfNeeded()
                }
                swipeRefreshLayout.isRefreshing = false
            }

            override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                swipeRefreshLayout.isRefreshing = false
            }
        })
    }

    private fun showEmptyStateIfNeeded() {
        if (usersAdapter.itemCount == 0) {
            emptyStateTextView.visibility = View.VISIBLE
        } else {
            emptyStateTextView.visibility = View.GONE
        }
    }
}

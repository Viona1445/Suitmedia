package com.example.suitmediavionaasyaarinda.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.suitmediavionaasyaarinda.R
import com.example.suitmediavionaasyaarinda.databinding.ActivityFirstScreenBinding

class FirstScreenActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFirstScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFirstScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupAction()
    }

    private fun setupAction() {
        binding.buttonCheck.setOnClickListener {
            val palindrome = binding.CVPalindrome2.text.toString()
            var isPalindrome = true

            if (palindrome.isEmpty()) {
                binding.CVPalindrome2.error = "Must be filled!"
                isPalindrome = false
            }

            val reversedPalindrome = palindrome.reversed()
            if (palindrome != reversedPalindrome) {
                isPalindrome = false
            }

            showResultDialog(isPalindrome)
        }

        binding.buttonNext.setOnClickListener {
            val name = binding.CVName.text.toString()
            if (name.isEmpty()) {
                binding.CVName.error = "Must be filled!"
            } else {
                moveToSecondScreen(name)
            }
        }
    }

    private fun moveToSecondScreen(name: String) {
        val intent = Intent(this, SecondScreenActivity::class.java).apply {
            putExtra("NAME_USER", name)
        }
        startActivity(intent)
    }

    private fun showResultDialog(isPalindrome: Boolean) {
        val message = if (isPalindrome) "Palindrome" else "Not Palindrome"
        val alertDialog = AlertDialog.Builder(this)
            .setTitle("isPalindrome")
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .create()

        alertDialog.show()
    }
}

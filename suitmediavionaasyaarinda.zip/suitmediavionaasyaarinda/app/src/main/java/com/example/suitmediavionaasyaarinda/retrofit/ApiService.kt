package com.example.suitmediavionaasyaarinda.retrofit

import com.example.suitmediavionaasyaarinda.response.UserResponse
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.Call

interface ApiService {

    @GET("api/users?page=1&per_page=10")
    fun getUsers(
        @Query("page") page: Int,
        @Query("per_page") perPage: Int
    ): Call<UserResponse>
}